from setuptools import setup

setup(
	name='myhellolib',
	version=['0.0.1'],
	packges=['myhellolib'],
	install_requires=['requires','importlib; python_version == "3.7.9"']
)
